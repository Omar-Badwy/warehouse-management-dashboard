import CategoryForm from "../../forms/categoryForm";
import { useContext } from "react";
import BaseModal from "../baseModal";
import { ModalsContext } from "../../../providers/modalsProvider";
import { useDispatch, useSelector } from "react-redux";
import { addCat } from "../../../redux/features/slices/categoriesSlice";
import { validateCategory } from "../../../utils/validation/categoryValidation";
import { addNotification } from "../../../redux/features/slices/notificationsSlice";


function AddCategoryModal () {

    const { closeModal , categoryInput, setErrors, } = useContext(ModalsContext)

    const categories = useSelector( (state) => state.categories.categories)

    const dispatch = useDispatch()

    function handleAddCategory () {

        const type = "add"
        let validationErrors = validateCategory(categoryInput,categories,setErrors,type)
        if(Object.keys(validationErrors).length === 0){

            dispatch(addCat({data: categoryInput,}))
            dispatch( addNotification({
                type: "success",
                title: "category added",
                message: `New category "${categoryInput.name}" was added successfully.`,
            }) )
            closeModal()
        }
    }

    return(
        <>
            <BaseModal title="add new category" onSubmit={handleAddCategory}>
                <CategoryForm/>
            </BaseModal>
        </>
    )
}

export default AddCategoryModal;