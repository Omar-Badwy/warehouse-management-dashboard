import { Input } from "@mantine/core";
import styles from '../../styles/modals.module.css'

function TextInput ({type,name,placeholder,error,value,onChange}) {

    return(
        <>
            <Input.Wrapper classNames={{label: styles.label, error: styles.error,}} 
                 error={error}>

                <input type={type} name={name} className={styles.input} placeholder={placeholder}

                value={value} onChange={onChange}/>
            </Input.Wrapper>
        </>
    )
}

export default TextInput;